# 🎓 EduSphere Virtual Classroom Platform

A fully functional multi-page virtual classroom for full-stack web development mastery.

## 📁 File Structure

```
edusphere/
├── server.js          ← Express backend (Node.js)
├── package.json       ← Dependencies
├── styles.css         ← Shared design system styles
├── nav.js             ← Shared navigation injector
├── shared.js          ← Auth, toasts, PDF generator
├── index.html         ← 🏠 Home Page
├── curriculum.html    ← 📚 Full Curriculum (HTML→TS)
├── classroom.html     ← 🎥 Live Video Classroom
├── tools.html         ← 🛠️ Dev Tools (Editor, Colors)
├── collaborate.html   ← 🤝 Pair Programming & Groups
├── resources.html     ← 📖 HTML/CSS/JS References
├── quiz.html          ← 🧪 Unit Quizzes (50 questions)
├── enroll.html        ← 📝 Sign Up + PDF Generator
└── home.css           ← Home page specific styles
```

## 🚀 Getting Started

```bash
npm install
npm start
# Open http://localhost:3000
```

## ✨ Features

| Feature | Details |
|---------|---------|
| **Sign Up / Sign In** | User data saved in localStorage + backend |
| **PDF Generation** | Enrollment card with learning goals auto-downloaded |
| **Curriculum** | 6 units, HTML→CSS→JS→TypeScript, code examples |
| **Live Classroom** | Real camera + mic via getUserMedia, screen share |
| **Quizzes** | 50 questions across 5 units with explanations |
| **Resources** | Full HTML/CSS/JS reference tables + cheat sheets |
| **Code Editor** | Live HTML/CSS/JS editor with preview |
| **Collaborate** | Pair rooms, study groups, Kanban board |

## 🔑 API Routes

| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/enroll` | Register new student |
| POST | `/api/signin` | Sign in |
| GET | `/api/users` | All enrolled students |
| GET | `/api/units` | Curriculum units |
| GET | `/api/quiz/:unitId` | Quiz questions |
| POST | `/api/quiz/score` | Save quiz score |
| GET | `/api/session/status` | Live session info |
